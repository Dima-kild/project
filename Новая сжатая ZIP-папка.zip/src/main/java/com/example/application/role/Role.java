package com.example.application.role;

public enum Role {
    RESTAURANT , SUPPLIER
}
