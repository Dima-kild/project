package com.example.application;

import com.example.application.dataBase.CreatingDB;

public class app {
    public static void main(String[] args) {
        CreatingDB creatingDB = new CreatingDB();
        creatingDB.creatDB();
    }
}
